# 330-group-project
ISTE 330 Faculty Research Database project
# Group members:
Evan Reighter
Alex Leute
Michael McIntosh
Teo Luciani
Adrian Marquez